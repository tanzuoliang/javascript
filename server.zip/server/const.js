let SERVER_CONST = {
	ROOM_NUM	: 1,		
	INIT 	: 	"init",
	ENTER	:	"enter",
	START	:	"start",
	REDAY	:	"ready",
	CLOSE	: 	"close",
	GAME_OVER:	"gameOver",
	RE_CONN	:	"reConn"	
}

module.exports.SERVER_CONST = SERVER_CONST;