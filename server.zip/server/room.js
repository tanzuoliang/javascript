'use strict'

const SOCK = require("./sockClient").Sock

const gameConfig = require("./gameConfig").gameConfig

class Room{
	
	constructor(rid,userNum=1){
		this.rid = rid;
		this.sockList = [];
		this.userList = [];
		this.userNum = userNum;
		
		this.actionList = [];
		
		this.currentFrameIndex = 0;
		this.gameStart = false;
		
		
		this.roomTime = 0;
		this.frameTime = 80;
		this.runtime = 0;
		this.lastTime = new Date().getTime();
		
		this.readyCount = 0;
	}
	
	
	update(){

		var now = new Date().getTime();
		var pass = now - this.lastTime;
		this.lastTime = now;
		this.roomTime += pass;		
		if(this.roomTime >= 177000){
			this.actionList.push([12]);
			this.updateBroadMsg();
			this.gameOver();
			return;
		}
		
		this.runtime += pass;
		if(this.runtime > this.frameTime){
			this.runtime -= this.frameTime;
			this.updateBroadMsg();
		}
	}
	
	
	gameOver(){
		clearInterval(this.intervalID);
		
		manager.removeRoom(this.rid);
	}
	
	broadcastMsg (msg){
		for (let i = this.sockList.length - 1; i >= 0; i--) {
			this.sockList[i].send(JSON.stringify(msg));
		}
	};

	
	updateBroadMsg(){
		
		var nowTime = new Date().getTime();
		var actionHead = [this.currentFrameIndex,nowTime];
		this.actionList.unshift(actionHead);
		var frameData = JSON.stringify(this.actionList);
		this.broadcastMsg(this.actionList);
		//this.timeline.addFrameData(this.currentFrameIndex, frameData);
		this.actionList.length = 0;
		this.currentFrameIndex++;
	}
	
	addSock(sock){
		sock.setRoomId(this.rid);
		this.sockList.push(sock);
		this.userList.push(sock.toString());
		sock.initSuccess();
		
		if(this.sockList.length == this.userNum){
			this.startGame()
			return true;
		}
		
		return false;
	}
	
	//id,tank_id,ws,camp,props
	clientReConnection(ws,id){
		for (var i = 0; i < this.sockList.length; i++) {
			if(this.sockList[i].id == id){
				this.sockList.splice(i,1)
				break;	
			}
		}
		
		this.addSock(new SOCK(id, null, ws, null, null));

	}
	
	//客户端准备好了
	clientReady (id){
		for (var i = 0; i < this.sockList.length; i++) {
			if(this.sockList[i].id == id){
				this.sockList[i].isReady = true;
				this.readyCount++;
				break;
			}
		}
		
		if(this.readyCount == this.sockList.length){
			this.intervalID = setInterval(()=>{this.update();},10);
			this.broadcastMsg([[-5,0,0],{"type":"fight"}]);
		}
	}
	
	removeSockById(id){
		
		for (var i = 0; i < this.sockList.length; i++) {
			if(this.sockList[i].id == id){
				this.sockList.splice(i, 1);
				break;
			}
		}
		
		if(this.sockList.length == 0){
			this.gameOver();	
		}
	}
	
	
	
	hasEle (data) {
		let dataStr = JSON.stringify(data);
		
		let isBomb = data[0] == 3 && gameConfig.skill[gameConfig.skill_group[data[3]].skill[0][1]].move_type == 4;
		
		for (let i = 0,cmd,len = this.actionList.length ; i < len; i++) {
			cmd = this.actionList[i];
			if(data[1] != cmd[1])continue;
			
			//过滤多个移动
			if(data[0] == 2 && cmd[0] == 2)return true;
			//相同指令数据
			if(JSON.stringify(cmd) == dataStr)return true;
			
			//自爆坦克
			if(isBomb){
				if(cmd[0] == 2)return true;
			}
			else{
				
				if(data[0] == 2 && cmd[0] == 3 && gameConfig.skill[gameConfig.skill_group[cmd[3]].skill[0][1]].move_type == 4)return true
			}
			
			//转向和移动只要一个就可以了
//			if(data[0] == 1 || data[0] == 2){
//				return (data[0] == 1 && cmd[0] == 2) || (data[0] == 2 && cmd[0] == 1);
//			}
			
		}
		
		return false;
	};

	/*
	
	* addAction frame = 0 , data : [[[2,"117_1",2],[2,"123_1",2],[2,"129_1",2]]]
	* filter command : [2,"117_1",2]
	* filter command : [2,"123_1",2]
	* filter command : [2,"129_1",2]
	
	*/
	reciveActionsFromClient(data){
		var headData = data.shift();
		console.log("addAction frame = " + this.currentFrameIndex + " , data : " + JSON.stringify(data));
		for(var i = 0 , cmd,len = data[0].length; i < len;i++){
			cmd = data[0][i];
			if(!this.hasEle(cmd)){
				this.actionList.push(cmd);
			}
			else{
				
				console.log("filter command : " + JSON.stringify(cmd) + " , " + JSON.stringify(this.actionList));
				
			}
		}

	}
	
	startGame(){
		console.log("start Game");
		for (let i = 0; i < this.sockList.length; i++) {
			this.sockList[i].startSuccess(this.userList);
		}
		
		manager.currentRoomStartGame();
		
	}
	
}


class RoomManager{
	constructor(){
		this.roomMap = {};
		this.currentRoom = null;
		this.room_id = 0;
	}
	
	getRoom(rid){
		return this.roomMap[rid]
	}
	
	newRoom(roomNum=1){
		if(this.currentRoom == null){
			this.currentRoom = this.roomMap[this.room_id] = new Room(this.room_id,roomNum);
		}
		
		return this.currentRoom;
	}
	
	removeRoom(rid){
		delete this.roomMap[rid];
	}
	
	currentRoomStartGame(){
		
		this.currentRoom = null;
		this.room_id++;
	}
	
	getCurrentRoom(){
		return this.currentRoom;
	}
	
}

let manager = new RoomManager();

module.exports.RoomManager = manager;